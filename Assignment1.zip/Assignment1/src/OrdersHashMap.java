

import java.util.ArrayList;
import java.util.HashMap;

public class OrdersHashMap {

	public static HashMap<String, ArrayList<OrderItem>> orders = new HashMap<String, ArrayList<OrderItem>>();
	
	public OrdersHashMap() {
		
	}	
}
