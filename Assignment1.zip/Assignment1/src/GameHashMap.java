

import java.util.HashMap;

public class GameHashMap {
	public static HashMap<String, Game> electronicArts = new HashMap<String, Game>();
	public static HashMap<String, Game> activision = new HashMap<String, Game>();
	public static HashMap<String, Game> takeTwoInteractive = new HashMap<String, Game>();
	
	public static String string_apple = "Apple";
	public static String string_microsoft = "Microsoft";
	public static String string_samsung = "Samsung";
	
	public GameHashMap() {
		if(electronicArts.isEmpty()){

		}
		if(activision.isEmpty()){
	
		}
		if(takeTwoInteractive.isEmpty()){

		}
	}
}
