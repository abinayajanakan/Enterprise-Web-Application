public class Review{
	
	String productMN;
	String productC;
	String productId;
	Double productP;
	String productRN;
	String productRZ;
	String productRC;
	String productRS;
	String productOS;
	String productMrN;
	String productMR;
	String productRvU;
	String productRvA;
	String productRvG;
	String productRvO;
	String productRvD;
	String productRvS;
	String productRvB;
	Integer productRvR;	
	
	
	public void setProductMN(String productMN) {
		this.productMN = productMN;
	}
	
	public String getProductMN() {
		return productMN;
	}
	
	public void setProductP(Double productP) {
		this.productP = productP;
	}
	
	public Double getProductP() {
		return productP;
	}
	
	public void setProductC(String productC) {
		this.productC = productC;
	}
	
	public String getProductC() {
		return productC;
	}
	
	public void setProductRN(String productRN) {
		this.productRN = productRN;
	}
	
	public String getProductRN() {
		return productRN;
	}
	
	public void setProductId(String productId) {
		this.productId = productId;
	}
	
	public String getProductId() {
		return productId;
	}	
	
	public void setProductRZ(String productRZ) {
		this.productRZ = productRZ;
	}	
	
	public String getProductRZ() {
		return productRZ;
	}
	
	public void setProductRC(String productRC) {
		this.productRC = productRC;
	}
	
	public String getProductRC() {
		return productRC;
	}
	
	public void setProductRS(String productRS) {
		this.productRS = productRS;
	}
	
	public String getProductRS() {
		return productRS;
	}
	
	public void setProductOS(String productOS) {
		this.productOS = productOS;
	}
	
	public String getProductOS() {
		return productOS;
	}
	
	public void setProductMrN(String productMrN) {
		this.productMrN = productMrN;
	}
	
	public String getProductMrN() {
		return productMrN;
	}
	
	public void setProductMR(String productMR) {
		this.productMR = productMR;
	}
	
	public String getProductMR() {
		return productMR;
	}
	
	public void setProductRvU(String productRvU) {
		this.productRvU = productRvU;
	}
	
	public String getProductRvU() {
		return productRvU;
	}
	
	public void setProductRvA(String productRvA) {
		this.productRvA = productRvA;
	}
	
	public String getProductRvA() {
		return productRvA;
	}
	
	public void setProductRvG(String productRvG) {
		this.productRvG = productRvG;
	}
	
	public String getProductRvG() {
		return productRvG;
	}
	
	public void setProductRvO(String productRvO) {
		this.productRvO = productRvO;
	}
	
	public String getProductRvO() {
		return productRvO;
	}
	
	public void setProductRvD(String productRvD) {
		this.productRvD = productRvD;
	}
	
	public String getProductRvD() {
		return productRvD;
	}
	
	public void setProductRvS(String productRvS) {
		this.productRvS = productRvS;
	}
	
	public String getProductRvS() {
		return productRvS;
	}
	
	public void setProductRvB(String productRvB) {
		this.productRvB = productRvB;
	}
	
	public String getProductRvB() {
		return productRvB;
	}
	
	public void setProductRvR(Integer productRvR) {
		this.productRvR = productRvR;
	}
	
	public Integer getProductRvR() {
		return productRvR;
	}
	
}